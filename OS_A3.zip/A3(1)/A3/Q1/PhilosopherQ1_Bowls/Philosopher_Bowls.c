#include<stdio.h>
#include<semaphore.h>
#include<stdlib.h>
#include<pthread.h>
#include<time.h>

sem_t s1,s2,s3,s4,s5;
sem_t bowl1;

sem_t *list[5];
// sem_t *bowls[2];
void* func(void *ptr){
    int value1, value2, count[2],flag = 0;
    sem_wait(&bowl1);
    printf("\n\nPhilosopher%d acquired bowl for eating\n", *(int*)ptr);
    for(int i = 0;i<5;i++){
        sem_getvalue(list[i], &value1);
        if(value1 > 0 && flag < 2){
            sem_wait(list[i]);
            count[flag] = i;
            flag++;
        }else if(flag > 2){
            break;
        }
    }
    printf("Philosopher%d start eating\n", *(int*)ptr);
    printf("Philosopher%d eat with bowl, folk%d and folk%d\n\n",*(int*)ptr , count[0]+1, count[1] + 1);
    
    sem_post(list[count[0]]);
    sem_post(list[count[1]]);
    sem_post(&bowl1);
}

void* func1(void *ptr){
    int value1, value2, count[2],flag = 0;
    sem_wait(&bowl1);
    printf("\n\nPhilosopher%d acquired bowl for eating\n", *(int*)ptr);
    for(int i = 3;i<5;i++){
        sem_getvalue(list[i], &value1);
        if(value1 > 0 && flag < 2){
            sem_wait(list[i]);
            count[flag] = i;
            flag++;
        }else if(flag > 2){
            break;
        }
    }
    printf("Philosopher%d start eating\n", *(int*)ptr);
    printf("Philosopher%d eat with bowl, folk%d and folk%d\n\n",*(int*)ptr , count[0]+1, count[1] + 1);
    
    sem_post(list[count[0]]);
    sem_post(list[count[1]]);
    sem_post(&bowl1);
}

int main(){

    sem_init(&s1, 0, 1);
    sem_init(&s2, 0, 1);
    sem_init(&s3, 0, 1);
    sem_init(&s4, 0, 1);
    sem_init(&s5, 0, 1);
    sem_init(&s5, 0, 2);
    sem_init(&bowl1, 0, 2);

    list[0] = &s1;
    list[1] = &s2;
    list[2] = &s3;
    list[3] = &s4;
    list[4] = &s5;



    pthread_t t1,t2,t3,t4,t5;
    int nums[5] = {1,2,3,4,5};
    pthread_create(&t1, NULL, func, &nums[0]);
    pthread_create(&t2, NULL, func1, &nums[1]);
    pthread_create(&t3, NULL, func, &nums[2]);
    pthread_create(&t4, NULL, func1, &nums[3]);
    pthread_create(&t5, NULL, func, &nums[4]);

    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    pthread_join(t3, NULL);
    pthread_join(t4, NULL);
    pthread_join(t5, NULL);

    for(int i = 0;i<5;i++){
        sem_destroy(list[i]);
    }
    sem_destroy(&bowl1);
    return 0;
}