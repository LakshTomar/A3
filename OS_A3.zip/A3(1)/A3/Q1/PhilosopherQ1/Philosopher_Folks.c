#include<stdio.h>
#include<semaphore.h>
#include<stdlib.h>
#include<pthread.h>
#include<time.h>

sem_t folk1, folk2, folk3, folk4, folk5;
sem_t list[5];
void* func1(void * arg){
    // int value, count = 0;
    // int folk_value[2];
    // sem_t folks[2];
    // for(int i = 0;i<5;i++){
    //     sem_getvalue(&list[0], &value);
    //     if(value == 1 && count < 2){
    //         sem_wait(&list[i]);
    //         printf("Philosopher1 Acuired Folk%d\n", i+1);
    //         folks[count] = list[i];
    //         folk_value[count++] = i;
    //     }else if(count == 1){
    //         break;
    // }
    // }
    // printf("Philosopher1 eating with  folk%d and folk%d\n", folk_value[0]+1, folk_value[1] + 1);
    // printf("Philosopher1 eating\n");
    // sem_post(&folks[0]);
    // sem_post(&folks[1]);

    sem_wait(&list[0]);
    sem_wait(&list[1]);

    printf("\n\nPhilosopher1 eating with  folk1 and folk2\n");
    printf("Philosopher1 eating\n");
    printf("Philosopher1 Complete eating\n");
    printf("Philosopher1 going to release fork1 and folk2\n\n");

    sem_post(&list[0]);
    sem_post(&list[1]);



}

void* func2(void * arg){
    // int value, count = 0;
    // int folk_value[2];
    // sem_t folks[2];
    // for(int i = 0;i<5;i++){
    //     sem_getvalue(&list[0], &value);
    //     if(value == 1 && count < 2){
    //         sem_wait(&list[i]);
    //         printf("Philosopher2 Acuired Folk%d\n", i+1);
    //         folks[count] = list[i];
    //         folk_value[count++] = i;
    //     }else if(count == 1){
    //         break;
    // }
    // }
    // printf("Philosopher2 eating with  folk%d and folk%d\n", folk_value[0]+1, folk_value[1] + 1);
    // printf("Philosopher2 eating\n");
    // sem_post(&folks[0]);
    // sem_post(&folks[1]);

    sem_wait(&list[1]);
    sem_wait(&list[2]);

    printf("\n\nPhilosopher2 eating with  folk2 and folk3\n");
    printf("Philosopher2 eating\n");
    printf("Philosopher2 Complete eating\n");
    printf("Philosopher2 going to release fork2 and folk3\n\n");


    sem_post(&list[2]);
    sem_post(&list[3]);

}

void* func3(void * arg){
    // int value, count = 0;
    // int folk_value[2];
    // sem_t folks[2];
    // for(int i = 0;i<5;i++){
    //     sem_getvalue(&list[0], &value);
    //     if(value == 1 && count < 2){
    //         sem_wait(&list[i]);
    //         printf("Philosopher3 Acuired Folk%d\n", i+1);
    //         folks[count] = list[i];
    //         folk_value[count++] = i;
    //     }else if(count == 1){
    //         break;
    // }
    // }
    // printf("Philosopher3 eating with  folk%d and folk%d\n", folk_value[0]+1, folk_value[1] + 1);
    // printf("Philosopher3 eating\n");
    // sem_post(&folks[0]);
    // sem_post(&folks[1]);

    sem_wait(&list[3]);
    sem_wait(&list[4]);

    printf("\n\nPhilosopher3 eating with  folk3 and folk4\n");
    printf("Philosopher3 eating\n");
    printf("Philosopher3 Complete eating\n");
    printf("Philosopher3 going to release fork3  and folk4\n\n");


    sem_post(&list[3]);
    sem_post(&list[4]);
}

void* func4(void * arg){
    //sleep(2);
    // int value, count = 0;
    // int folk_value[2];
    // sem_t folks[2];
    // for(int i = 0;i<5;i++){
    //     sem_getvalue(&list[0], &value);
    //     if(value == 1 && count < 2){
    //         sem_wait(&list[i]);
    //         printf("Philosopher4 Acuired Folk%d\n", i+1);
    //         folks[count] = list[i];
    //         folk_value[count++] = i;
    //     }else if(count == 1){
    //         break;
    // }
    // }
    // printf("Philosopher4 eating with  folk%d and folk%d\n", folk_value[0]+1, folk_value[1] + 1);
    // printf("Philosopher4 eating\n");
    // sem_post(&folks[0]);
    // sem_post(&folks[1]);

    sem_wait(&list[3]);
    sem_wait(&list[4]);

    printf("\n\nPhilosopher4 eating with  folk4 and folk5\n");
    printf("Philosopher4 eating\n");
    printf("Philosopher4 Complete eating\n");
    printf("Philosopher4 going to release fork4 and folk5\n\n");


    sem_post(&list[3]);
    sem_post(&list[4]);

}

void* func5(void * arg){
    //sleep(2);
    // int value, count = 0;
    // int folk_value[2];
    // sem_t folks[2];
    // for(int i = 0;i<5;i++){
    //     sem_getvalue(&list[0], &value);
    //     if(value == 1 && count < 2){
    //         sem_wait(&list[i]);
    //         printf("Philosopher5 Acuired Folk%d\n", i+1);
    //         folks[count] = list[i];
    //         folk_value[count++] = i;
    //     }else if(count == 1){
    //         break;
    // }
    // }
    // printf("Philosopher5 eating with  folk%d and folk%d\n", folk_value[0]+1, folk_value[1] + 1);
    // printf("Philosopher5 eating\n");
    // sem_post(&folks[0]);
    // sem_post(&folks[1]);

    sem_wait(&list[4]);
    sem_wait(&list[0]);

    printf("\n\nPhilosopher5 eating with  folk5 and folk1\n");
    printf("Philosopher5 eating\n");
    printf("Philosopher5 Complete eating\n");
    printf("Philosopher5 going to release fork5  and folk1\n\n");


    sem_post(&list[0]);
    sem_post(&list[4]);

}

int main(){

    sem_init(&folk1, 0, 1);
    sem_init(&folk2, 0, 1);
    sem_init(&folk3, 0, 1);
    sem_init(&folk4, 0, 1);
    sem_init(&folk5, 0, 1);

    list[0] = folk1;
    list[1] = folk2;
    list[2] = folk3;
    list[3] = folk4;
    list[4] = folk5;

    pthread_t t1, t2, t3, t4, t5;

    pthread_create(&t1, NULL, func1, NULL);
    pthread_create(&t2, NULL, func2, NULL);
    pthread_create(&t3, NULL, func3, NULL);
    pthread_create(&t4, NULL, func4, NULL);
    pthread_create(&t5, NULL, func5, NULL);


    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    pthread_join(t3, NULL);
    pthread_join(t4, NULL);
    pthread_join(t5, NULL);


    for(int i = 0;i<5;i++){
        sem_destroy(&list[i]);
    }
    return 0;
}
