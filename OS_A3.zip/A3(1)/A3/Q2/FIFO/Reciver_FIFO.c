#include<stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <stdlib.h>
#include<time.h>
#include<string.h>

struct My_Struct{
    int index;
    char str[51];
}s1, s2, s3, s4, s5;

int main(){

    mkfifo("/tmp/FIFO_Sender", 0666);
    mkfifo("/tmp/FIFO_Reader", 0666);

    struct My_Struct list[5] = {s1, s2, s3, s4, s5};
    struct timespec time1, time2;
    int reader, writer, fd1, fd2, index_Finally ,*ptr;

    fd1 = open("/tmp/FIFO_Sender", O_RDONLY);
    fd2 = open("/tmp/FIFO_Reader", O_WRONLY);

    if(fd1 == -1 || fd2 == -1){
        printf("Error - FIFO's not get opened");
    }else{
        clock_gettime(CLOCK_BOOTTIME, &time1);
        while(1){
            reader = read(fd1, list, sizeof(struct My_Struct) * 5);
            index_Finally = 0;
            for(int i = 0; i<5; i++){
                printf("%s %d\n", list[i].str, list[i].index);
                if(index_Finally <= list[i].index){
                    index_Finally = list[i].index;
                }
            }
            if(index_Finally == 49){
                writer = write(fd2, &index_Finally, sizeof(int));
                clock_gettime(CLOCK_BOOTTIME, &time2);
                printf("Time Taken to complete this task in nano second is: %ld\n", 1 * (time2.tv_nsec - time1.tv_nsec));
                // sleep(2);
                break;
            }

            writer = write(fd2, &index_Finally, sizeof(int));
            if(writer == -1){
                printf("Writer is failed\n");
            }
        }
        // wait(2);
        close(fd1);
        close(fd2);
    }

    return 0;
}