#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

// pthread_mutex_t folk1, folk2, folk3, folk4, folk5;


void* func1(void *arg){
    int *value = (int *)arg;

    if(*value == 1){
        // pthread_mutex_lock(&folk1);
        // pthread_mutex_lock(&folk2);

        printf("\n\nPhilosopher%d accquired folk1 and folk2\n", *value);
        printf("Philosopher%d complete with eating\n", *value);

        // pthread_mutex_unlock(&folk2);
        // pthread_mutex_unlock(&folk1);
    }
    else if(*value == 3){
        // pthread_mutex_lock(&folk3);
        // pthread_mutex_lock(&folk4);

        printf("\n\nPhilosopher%d accquired folk3 and folk4\n", *value);
        printf("Philosopher%d complete with eating\n", *value);

        // pthread_mutex_unlock(&folk4);
        // pthread_mutex_unlock(&folk3);
    }else if(*value == 5){
        // pthread_mutex_lock(&folk5);
        // pthread_mutex_lock(&folk1);

        printf("\n\nPhilosopher%d accquired folk1 and folk5\n", *value);
        printf("Philosopher%d complete with eating\n", *value);

        // pthread_mutex_unlock(&folk1);
        // pthread_mutex_unlock(&folk5);
    }else if(*value == 2){
        // pthread_mutex_lock(&folk2);
        // pthread_mutex_lock(&folk3);

        printf("\n\nPhilosopher%d accquired folk3 and folk2\n", *value);
        printf("Philosopher%d complete with eating\n", *value);

        // pthread_mutex_unlock(&folk3);
        // pthread_mutex_unlock(&folk2);
    }else if(*value == 4){
        // pthread_mutex_lock(&folk4);
        // pthread_mutex_lock(&folk5);

        printf("\n\nPhilosopher%d accquired folk4 and folk5\n", *value);
        printf("Philosopher%d complete with eating\n", *value);

        // pthread_mutex_unlock(&folk4);
        // pthread_mutex_unlock(&folk5);
    }
}

int main(){

    int *f1, *f2, *f3, *f4, *f5;

    f1 = malloc(sizeof(int));
    f2 = malloc(sizeof(int));
    f3 = malloc(sizeof(int));
    f4 = malloc(sizeof(int));
    f5 = malloc(sizeof(int));

    *f1 = 1;
    *f2 = 2;
    *f3 = 3;
    *f4 = 4;
    *f5 = 5;


    // pthread_mutex_init(&folk1, NULL);
    // pthread_mutex_init(&folk2, NULL);
    // pthread_mutex_init(&folk3, NULL);
    // pthread_mutex_init(&folk4, NULL);
    // pthread_mutex_init(&folk5, NULL);


    pthread_t p1, p2, p3, p4, p5;
    int i = 0;
    while(i != 100){
    pthread_create(&p1, NULL, func1, f1);
    pthread_join(p1, NULL);
    pthread_create(&p2, NULL, func1, f2);
    pthread_join(p2, NULL);

    pthread_create(&p3, NULL, func1, f3);
    pthread_join(p3, NULL);

    pthread_create(&p4, NULL, func1, f4);
    pthread_join(p4, NULL);

    pthread_create(&p5, NULL, func1, f5);
    pthread_join(p5, NULL);
    i++
}
    // pthread_join(p1, NULL);
    // pthread_join(p2, NULL);
    // pthread_join(p3, NULL);
    // pthread_join(p4, NULL);
    // pthread_join(p5, NULL);



    // pthread_mutex_destroy(&folk1);
    // pthread_mutex_destroy(&folk2);
    // pthread_mutex_destroy(&folk3);
    // pthread_mutex_destroy(&folk4);
    // pthread_mutex_destroy(&folk5);
    
    return 0;
}