Q3:
    for this question current variable is used to iterate over circular doubly linked list of task struct,
    and then print pid, pgid, user id and command path on the terminal. for printing values of the task struct printk 
    function is used in the. additional to that pid of process taken as input for printing these values.

    
