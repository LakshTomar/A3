#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include<time.h>

struct My_Struct{
    int num[5];
    char String[5][51];
}s;

int main(){
    struct timespec time1, time2;
    int largest_index = 0;
    int client_sock = socket(AF_INET, SOCK_STREAM, 0);
    if(client_sock < 0){
        printf("Error in creating the socket");
        return 0;
    }

    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    server_addr.sin_port = htons(8082);
    if (connect(client_sock, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("connect() failed");
        return 0;
    }

    char str[50];

    clock_gettime(CLOCK_BOOTTIME, &time1);
    while(1){
    if(recv(client_sock, &s, sizeof(struct My_Struct), 0) > 0){
        // printf("message recived is %s\n", str);
        largest_index = 0;
        for(int i = 0;i<5;i++){
            if(largest_index <= s.num[i]) largest_index = s.num[i];
            printf("Recived String is: %s and Unique Id is: %d\n", s.String[i], s.num[i]);
        }
    }

    if(largest_index == 49){
        clock_gettime(CLOCK_BOOTTIME, &time2);
        largest_index = -1;
        send(client_sock, &largest_index, sizeof(int), 0);
        break;
    }

    if(send(client_sock, &largest_index, sizeof(int), 0) < 0){
        printf("Error is Sending data from client\n");
        }
    }

    printf("\nTime taken to complete this task is: %ld\n", time2.tv_nsec - time1.tv_nsec);

    close(client_sock);
    return 0;
}