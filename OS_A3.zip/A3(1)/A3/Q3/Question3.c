#include <linux/module.h>
#include <linux.kernel.h>
#include <linux/init.h>
#include <linux/sched.h>
#include <linux/moduleparam.h>
#include <linux/stat.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Laksh");
MODULE_DESCRIPTION("OS_Assignment_Q3");
int pid_given = 0;

module_param(pid_given, int, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
MODULE_PARM_DESC(pid_given, "An integer");

void device_exit(void);
int device_init(void);
   
/* Declaration of the init and exit routines */
module_init(device_init);
module_exit(device_exit);
 
int device_init(void)
{
    int count  = 1;
    struct task_struct *task_use = current; // getting global current pointer
    struct task_struct *task = current; // getting global current pointer

    // struct task_struct *next;
    // next = task
    while(task_use->pid != pid_given){
        if(count != 1 && task_use == task){
            printk(KERN_NOTICE "Process of this id is not avaliable in circular doubly linked list of task struct\n");
            return 0;
        
        task = task->next_task;
        }
    }

    printk(KERN_NOTICE "Pid of current task struct is %d\n", task->pid);
    printk(KERN_NOTICE "gpid of current task struct is %d\n", task->gid);
    printk(KERN_NOTICE "uid of current task struct is %d\n", task->uid);

    return 0;
    
}
 
void device_exit(void) {
  printk(KERN_NOTICE "assignment: exiting module");
}