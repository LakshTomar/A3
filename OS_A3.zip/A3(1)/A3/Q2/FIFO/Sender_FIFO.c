#include<stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <stdlib.h>
#include<time.h>
#include<string.h>

struct My_Struct{
    int index;
    char str[51];
}s1, s2, s3, s4, s5;

char Strings[50][51];

void Generate_Strings(){
    srand(time(0));
    for(int i = 0; i<50;i++){
        for(int j = 0; j<50; j++){
            Strings[i][j] = 'a' + rand() % 26;
        }
        Strings[i][51] = '\0';
        // printf("%s\n", Strings[i]);
    }
}



int main(){


    int writer, reader, Reciver_Int;
    struct timespec time1;
    struct timespec time2;

    Generate_Strings();

    struct My_Struct list[5] = {s1, s2, s3,s4, s5};

    for(int i = 0; i<5 ;i++){
        list[i].index = i;
        strcpy(list[i].str, Strings[i]);
        // printf("%s\n", list[i].str);
    }

    mkfifo("/tmp/FIFO_Sender", 0666);
    mkfifo("/tmp/FIFO_Reader", 0666);

    // struct My_Struct list[5];

    int fd1 = open("/tmp/FIFO_Sender", O_WRONLY);
    int fd2 = open("/tmp/FIFO_Reader", O_RDONLY);

    if(fd1 == -1 || fd2 == -1){
        printf("Error - FIFO's not get opened");
    }

    else {
        
        clock_gettime(CLOCK_BOOTTIME, &time1);

        while(1){

        writer = write(fd1, list, sizeof(struct My_Struct) * 5);
        //sleep(2);
        reader = read(fd2, &Reciver_Int, sizeof(int));
        // sleep(2);
        if(Reciver_Int == 49){
            //printf("String With Biggest Number is %s\n", Strings[Reciver_Int]);
            break;
        }else if(Reciver_Int < 49){
            //printf("Revived index is : %d and String is : %s  \n", Reciver_Int, Strings[Reciver_Int]);
            for(int i = 0; i<5; i++){
                if(i + Reciver_Int < 49){
                    list[i].index = Reciver_Int + i;
                    strcpy(list[i].str, Strings[Reciver_Int + i]);
                }else if(Reciver_Int + i >= 49){
                    list[i].index = 49;
                    strcpy(list[i].str, Strings[49]);
                }
            }
        }

        }
        // close(fd1);
        // close(fd2);
        clock_gettime(CLOCK_BOOTTIME, &time2);

        //printf("Time in Nano Second to complete task: %d \n", time2.tv_nsec - time1.tv_nsec);
        
    }

    return 0;
}