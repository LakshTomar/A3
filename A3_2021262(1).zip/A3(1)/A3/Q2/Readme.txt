Q2:
	FIFO: So for this two fifo (sender and reciver) are used one for sending strings and other for reciving highest index. Total time taken to complete the task is printed in the console which run reciver process(i.e. p2)
		Mutal exclusion is automatically avoided by read and write syscall as they work on blocking in nature. Additonally struct is used to send data beacuse by using it easily data transfer happen.
		
		Process1: open sender fifo in write mode and reciver fifo in read mode.
		Process2: vice versa for this process.
		
	
	Socket:

		port number used = 8082		

		Server process(process1):
			firstly basic step opensocket , bind, listen, accept, write, read, close are used to making server side socket. Same method of sending data is used here. And mutal exclusion 
			in taken care automatically by send/recv function from socket.

		reciver process(process2): 
			opensocket ,connect, read, write, close are used for this socket creation. And rest of all stuff same as mentioned above. In this also time is displayed on the console on which 
			client is running.

		 
	shared memory:
			
			key used for shared region is = 1124

			process1: this process create shared memory region and attach to itself this can be done by using shmget, shmat functions respectively. In this same structure approach is used for sending the
			data. Mutal exclusion is avoided by using sleep syscall which is gone be used after every write operation so that another sleeping process got time to wakeup and perform the task.

			process2: Similarly to process1 this process attach that segment to itself using shmget and shmat functions respectively. like all other process time in printed to complete the task
			is printed in this process console.

Hence at the end time for shared memory is minimun then socket and then fifo.