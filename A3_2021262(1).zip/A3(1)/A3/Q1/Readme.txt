Q1:
	Philospher :
			part 1:- without synchronization primitive

                Enforce an sequential rule for philospher to pick fork on the circular table that is discussed on the class.
                
			part 2:- with synchronization

                same approach using here but the diffrence is here we are using semaphore and its functions sem_wait and sem_post instead of
				enforcing strict rule to pick fork. Five binary semaphore are representing fork.

	Philosopher-Bowl:
			
        part1:- with synchronization
            	For this problem counting semaphore is used for bowls and binary semaphore is used for folks. So the basic logic is that first allocate bowls to 
				the philospher then folks to them. By using this deadlock easily prevented. Beacuse first assign two bowl lead to rest three philosopher into sleep, then distribution of 
				folks become easy.

        part2:- without synchronization

                similar rule enforced as do in Philospher part a.


            