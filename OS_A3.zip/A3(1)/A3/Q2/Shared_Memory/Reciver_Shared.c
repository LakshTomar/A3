#include<stdio.h>
#include<stdlib.h>
#include<sys/shm.h>
#include<string.h>
#include<unistd.h>
#include<time.h>
#include<semaphore.h>
#include<sys/stat.h>
#include<fcntl.h>

struct My_Struct{
    int num[5];
    int sender;
    char str[5][51];
};



int main(){

    char *sem_name1 = "semaphore1";
    char *sem_name2 = "semaphore2";

    sem_t *sem1;
    sem_t *sem2;

    struct timespec time1, time2;
    // sem_t *sem;
    // sem = sem_open("/mysem4", O_CREAT, 0644, 1);
    sem1 = sem_open(sem_name1, O_CREAT, 0666, 0);
    sem2 = sem_open(sem_name2, O_CREAT, 0666, 0);

    int index_finally, count =0;
    int shmid = shmget((key_t)1124, sizeof(struct My_Struct), 0666);
    void* shared_memory = shmat(shmid, NULL, 0);

    struct My_Struct *struct_ptr = (struct My_Struct*) shared_memory;
    clock_gettime(CLOCK_BOOTTIME, &time1);
    while(1){
        count++;
        index_finally = 0;
        // sem_wait(sem);
        sem_wait(sem1);
        for(int i = 0;i<5; i++){
            if(index_finally <= struct_ptr->num[i]) index_finally = struct_ptr->num[i];
            printf("Recived id: %d and String is: %s\n", struct_ptr->num[i], struct_ptr->str[i]);
        }
        // sem_post(sem);
        if(index_finally == 49){
            struct_ptr->sender = index_finally;
            break;
        }
        struct_ptr->sender = index_finally;
        // sleep(2);
        sem_post(sem2);
    }
    clock_gettime(CLOCK_BOOTTIME, &time2);
    printf("Required time for completing this task is : %ld\n", time2.tv_nsec - time1.tv_nsec - count * 100000000);
    
    sem_close(sem_name1);
    sem_close(sem_name2);
    sem_unlink(sem1);
    sem_unlink(sem2);
    return 0;
}