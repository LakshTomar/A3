#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/sched.h>
#include <linux/moduleparam.h>
#include <linux/stat.h>
#include <linux/proc_fs.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Lakshya");
MODULE_DESCRIPTION("Reading Entries of task struct of any process");

static int variable = 1;
module_param(variable, int, 0644);
MODULE_PARM_DESC(variable, "Integer parameter for variable");

void device_exit(void);
int device_init(void);
   
/* Declaration of the init and exit routines */
module_init(device_init);
module_exit(device_exit);
 
int device_init(void)
{
    char path[] = "insmod";
    // printk(KERN_NOTICE "Interger taken is %d\n", variable);
    struct task_struct *task = current; // getting global current pointer
    struct task_struct *task1;
    // printk(KERN_NOTICE "assignment: current process: %s, PID: %d, user id %d\n", task->comm, task->pid, task->real_cred->uid);
    for_each_process(task){
      if(task->pid == variable){
          printk(KERN_NOTICE "Got the required task struct\n");
          printk(KERN_NOTICE "command path %s, pid: %d\n", task->comm, task->pid);
          // printk(KERN_NOTICE "pid is %d\n", task->pid);
          printk(KERN_NOTICE "uid is %d\n",task->real_cred->uid);
          printk(KERN_NOTICE "guid is %d\n",task->cred->gid.val);

      return 0;
      }
    }
    return 0;
}
 
void device_exit(void) {
  printk(KERN_NOTICE "assignment: exiting module");
}
