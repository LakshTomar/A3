#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>

char Strings[50][51];

void Generate_Strings(){
    srand(time(0));
    for(int i = 0; i<50;i++){
        for(int j = 0; j<50; j++){
            Strings[i][j] = 'a' + rand() % 26;
        }
        Strings[i][51] = '\0';
        // printf("%s\n", Strings[i]);
    }
}

struct My_Struct{
    int num[5];
    char String[5][51];
}s;

int main(){
    int Readed_Int = 0;
    Generate_Strings();

    int server_sock = socket(AF_INET, SOCK_STREAM, 0);
    if(server_sock < 0){
        printf("Error occured in socket creating\n");
        return 0;
    }

    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    server_addr.sin_port = htons(8082);

      if (bind(server_sock, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0){
        printf("Error in binding the socket\n");
        return 0;
      }

      if(listen(server_sock, 1) < 0){
        printf("Error in setup for listen\n");
        return 0;
      }

    struct sockaddr_in client_addr;
    socklen_t client_addr_len = sizeof(client_addr);
    int client_sock = accept(server_sock, (struct sockaddr*)&client_addr, &client_addr_len);
    if(client_sock < 0){
        printf("Error in accepting the connection for client\n");
    }

    char *str = "Hello Client i am server";

    for(int i = 0;i<5;i++){
        s.num[i] = i;
        strcpy(s.String[i], Strings[i]);
    }
    
    while(1){

        if(send(client_sock, &s, sizeof(struct My_Struct), 0) < 0){
            printf("Error in sending the message to the client\n");
        }

        if(recv(client_sock, &Readed_Int, sizeof(int), 0) > 0){
            if(Readed_Int == -1){
                printf("Task Completed\n");
                break;
            }else{
                for(int i = 1;i<6;i++){
                    if(Readed_Int + i < 49){
                        s.num[i-1] = Readed_Int + i;
                        strcpy(s.String[i], Strings[Readed_Int + i-1]);
                    }else if(Readed_Int + i >= 49){
                        s.num[i-1] = 49;
                        strcpy(s.String[i-1], Strings[49]);
                    }
                }
            }
        }
    }
    close(client_sock);
    close(server_sock);
}