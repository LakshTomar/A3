Q3:
    In this question for a given process we have to print pid, gpid, uid, and command path.
    For that we are using for_each_process(struct task_struct *ptr) is used by as mentioned over internet to use it. Then by using this function we can iterate over
    the circular doubly linked list of task_struct as discussed in the class. The parameter passed over the module by using module_param and MODULE_PARM_DESC functions.
    After got the required task_struct of a process we can print the following things of the process command path, pid, gpid, upid. 

    For the module:-
    
    MODULE_LICENSE = "GPL";
    MODULE_AUTHOR = "Lakshya";
    MODULE_DESCRIPTION = "Reading entries of task struct of any process";
    
    is defined in it.
