#include<stdio.h>
#include<stdlib.h>
#include<sys/shm.h>
#include<string.h>
#include<unistd.h>
#include<time.h>
#include<semaphore.h>
#include<sys/stat.h>
#include<fcntl.h>

struct My_Struct{
    int num[5];
    int sender;
    char str[5][51];
};


char Strings[50][51];

void Generate_Strings(){
    srand(time(0));
    for(int i = 0; i<50;i++){
        for(int j = 0; j<50; j++){
            Strings[i][j] = 'a' + rand() % 26;
        }
        Strings[i][51] = '\0';
        // printf("%s\n", Strings[i]);
    }
}

int main(){

    char *sem_name1 = "semaphore1";
    char *sem_name2 = "semaphore2";

    sem_t *sem1;
    sem_t *sem2;

    sem1 = sem_open(sem_name1,O_CREAT,0666, 0);
    sem2 = sem_open(sem_name2,O_CREAT,0666, 0);
    // sem = sem_open("/mysem4", O_CREAT, 0644, 1);
    int count = 0;
    struct My_Struct *list[5];

    Generate_Strings();

    int shmid = shmget((key_t)1124, sizeof(struct My_Struct) , 0666 | IPC_CREAT);
    void *shared_memory=  shmat(shmid, NULL, 0);

    struct My_Struct *struct_ptr = (struct My_Struct *) shared_memory;

    // sem_wait(sem);
    for(int i = 0;i<5;i++){
        struct_ptr->num[i] = i;
        strcpy(struct_ptr->str[i], Strings[i]);
        //printf("%s \n", struct_ptr->str[i]);
    }
    sem_post(sem1);
    sem_wait(sem2);
    // sem_post(sem);
    // sleep(5);
    while(1){   
        // sem_wait(sem);
        if(struct_ptr->sender < 49){
            if(struct_ptr->sender == 49){
                break;
            }
            for(int i =1, j = 0 ;i<6 && j < 5;i++, j++){
                if(struct_ptr->sender + i < 49){
                    struct_ptr->num[j] = i + struct_ptr->sender;
                    strcpy(struct_ptr->str[j], Strings[struct_ptr->num[j]]);
                }
                else if(struct_ptr->sender + i >= 49){
                    struct_ptr->num[j] = 49;
                    strcpy(struct_ptr->str[j], Strings[49]);
                }else if(struct_ptr->sender + i >= 49 && i == 5){
                    return 0;
                }
            }
            sem_post(sem1);
            sem_wait(sem2);
            if(count > 0){break;}
        }
        // sem_post(sem);
        // sleep(2);
    }
    sem_close(sem_name1);
    sem_close(sem_name2);
    sem_unlink(sem1);
    sem_unlink(sem2);

    return 0;
}